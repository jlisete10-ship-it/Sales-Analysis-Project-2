-- Block 3: 

drop table sales

create table IF NOT EXISTS sales(
id serial primary key,
customer TEXT,
product TEXT,
val INT,
quantity INT
);

INSERT INTO sales(customer,product,val,quantity)
VALUES
('Ana','Keyboard',60,1),
('Rui' ,'Monitor',200,2.0),
('Unknown','Mouse',0,3),
('Marta','Unknown',150,1),
('Ana','Monitor',0,1),
('Rui','Keyboard',90,2),
('unknown','chair',120,1);

select *from sales;

-- Question 1: Total per customer

select customer, sum(quantity*val) as total_spent
from sales
group by customer
order by total_spent DESC;

-- Question 2: Customer above average
select customer, sum(quantity*val) as total
from sales
group by customer
HAVING sum(quantity*val) > (select avg(total)
from (select customer, sum(quantity*val) as total
from sales
group by customer)t
);