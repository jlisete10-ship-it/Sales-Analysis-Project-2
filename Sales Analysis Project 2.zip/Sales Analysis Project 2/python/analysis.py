import pandas as pd

df = pd.DataFrame({
    "customer": ["Ana", "Rui", None, "Marta", "Rui", "Ana", None],
    "product": ["Keyboard", "Monitor", "Mouse", None, "Keyboard", "Monitor", "Chair"],
    "value": ["60", "200", "error", "150", "90", None, "120"],
    "quantity": [1, 2, 3, None, 2, 1, 1]
})

print(df)
# Block 1  - Cleaning data:

df["customer"] = df["customer"].fillna("unknown")
df["product"] = df["product"].fillna("unknown")
df["value"] = pd.to_numeric(df["value"], errors="coerce")
df["value"] =df["value"].fillna(0).astype(int)
df["quantity"] =df["quantity"].fillna(1)

print(df.info())

#Block 2 - Analysis

#Question 1: Customer who spent the most

df["total_spent"] = df["quantity"] * df["value"]

print(df.groupby("customer")["total_spent"].sum().sort_values(ascending=False))

#Question 2: The most profitable product

print(df.groupby("product")["total_spent"].sum().sort_values(ascending=False))

#Question 3: Customers whose total spent is above average

total = df.groupby("customer")["total_spent"].sum() # gives me the total spent per customer
average = total.mean() 

print(total[total > average])# filters the clients whose total_spent is above average

#Question 4: Percentage of each customer
total_global = df["total_spent"].sum() # the sum of total spent of all customers

percentage = df.groupby("customer")["total_spent"].sum()

print(percentage/total_global*100)

print(df)

df.to_csv("sales2_ready.csv",index=False)
# Insight Questions:

#1. Who is the most important customer?
#Rui is the most important customer, as he is responsible for the highest share of total revenue and is the only customer above the average spending level.
#This indicates a strong concentration of sales in a single customer.
#2. Is there a business risk?
#Yes, there is a significant business risk.
#More than 50% of total revenue comes from a single customer (Rui), which creates a dependency.
#If this customer stops purchasing, it could have a major negative impact on the business.

#3.Which product have the most impact?
#The Monitor is the product with the highest impact on revenue.
#This is mainly due to its high unit price, meaning fewer sales can still generate significant revenue.
#This suggests that higher-priced products contribute more strongly to overall sales performance.








